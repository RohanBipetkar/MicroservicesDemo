package com.example.firstmicroservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstmicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstmicroserviceApplication.class, args);
	}

}
