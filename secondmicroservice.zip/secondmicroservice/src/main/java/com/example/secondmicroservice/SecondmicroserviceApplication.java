package com.example.secondmicroservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecondmicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecondmicroserviceApplication.class, args);
	}

}
